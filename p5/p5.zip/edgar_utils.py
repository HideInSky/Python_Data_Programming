import re
import netaddr
import pandas as pd
from bisect import bisect


file = 'ip2location.csv'
df = pd.read_csv(file)
low_c = df['low'].array

def lookup_region(ip):
    global low_c
    ipaddr = ip
    ipaddr = re.sub(r"[a-zA-Z]", "0", ipaddr)
    ipaddr = int(netaddr.IPAddress(ipaddr))
    idx = bisect(low_c, ipaddr) - 1
    return df.at[idx, 'region']

class Filing:
    def __init__(self, html):
        self.dates = re.findall(r'(?:19|20)\d{2}-\d{2}-\d{2}', html)
        sic = re.findall(r'SIC=(\d+)', html)
        if not sic:
            self.sic = None
        else:
            self.sic = int(sic[0])
        self.addresses = []
        for addr_html in re.findall(r'<div class="mailer">([\s\S]+?)</div>', html):
            lines = []
            for line in re.findall(r'<span class="mailerAddress">([\s\S]+?)</span>', addr_html):
                lines.append(line.strip())
            if not lines:
                continue
            self.addresses.append('\n'.join(lines))

    def state(self):
        for addr in self.addresses:
            reg = re.findall(r"([A-Z]{2}) \d{5}", addr)
            if reg:
                return reg[0]
        return None